"""Small contracts for the shared configuration and rendering architecture."""
from game.core.presentation import deep_merge


def test_deep_merge_preserves_nested_siblings_and_inputs():
    base = {"marco": {"height": 245, "left": 62}, "phone": [1, 2]}
    override = {"marco": {"height": 260}}
    result = deep_merge(base, override)
    assert result == {"marco": {"height": 260, "left": 62}, "phone": [1, 2]}
    result["marco"]["left"] = 999
    assert base["marco"]["left"] == 62
    assert override == {"marco": {"height": 260}}


def test_legacy_animation_import_remains_compatible():
    from game.systems.animation import LoopingAnimation
    from game.rendering.animation_renderer import LoopingAnimation as OldImport
    assert LoopingAnimation is OldImport
