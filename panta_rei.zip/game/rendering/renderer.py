"""Compatibility import for the legacy fallback presentation renderer."""
from game.rendering.prototype_renderer import PrototypeRenderer

__all__ = ["PrototypeRenderer"]
