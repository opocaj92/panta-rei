"""Compatibility import: use game.rendering.silhouette_renderer in new code."""
from game.rendering.silhouette_renderer import LoveSilhouetteRenderer

__all__ = ["LoveSilhouetteRenderer"]
