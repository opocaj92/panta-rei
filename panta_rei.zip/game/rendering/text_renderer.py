import pygame
from game.core.typography import Typography


class TextRenderer:
    """Reusable typography/UI presentation for the 640x360 design canvas."""

    def __init__(self, assets):
        self.assets = assets
        self.overlay = None
        self.scale = 1.0
        self.typography = Typography(assets)
        self.font = self.typography.font("dialogue")
        self.speaker_font = self.typography.font("speaker")
        self.thought_font = self.typography.font("thought")
        self.help_font = self.typography.font("help")
        self._font_styles = {id(self.font): "dialogue", id(self.speaker_font): "speaker",
                             id(self.thought_font): "thought", id(self.help_font): "help"}

    def begin_frame(self, size, scale):
        """Draw glyphs at output resolution, while boxes stay on the pixel canvas."""
        self.scale = float(scale)
        self.overlay = pygame.Surface(size, pygame.SRCALPHA)

    def _text(self, screen, font, label, color, x, y, center=False):
        if self.overlay is None:
            glyph = font.render(label, True, color)
            rect = glyph.get_rect(centerx=round(x), y=round(y)) if center else glyph.get_rect(topleft=(round(x), round(y)))
            screen.blit(glyph, rect)
            return
        # Use exactly the same font identity as the native-resolution layout.
        scale = self.scale
        style = self._font_styles[id(font)]
        high = self.typography.scaled(style, scale)
        glyph = high.render(label, True, color)
        # Align to the original glyph's ascent/height to avoid changing layout.
        if center:
            rect = glyph.get_rect(centerx=round(x * scale), y=round(y * scale))
        else:
            rect = glyph.get_rect(topleft=(round(x * scale), round(y * scale)))
        self.overlay.blit(glyph, rect)

    @staticmethod
    def _wrap(text, font, max_width):
        words = text.split(" ")
        lines, current = [], ""
        for word in words:
            candidate = word if not current else current + " " + word
            if font.size(candidate)[0] <= max_width:
                current = candidate
            else:
                if current:
                    lines.append(current)
                current = word
        if current:
            lines.append(current)
        return lines

    def dialogue(self, screen, dialogue, rect=None):
        line = dialogue.current_line
        if line is None:
            return
        rect = rect or pygame.Rect(51, 273, screen.get_width() - 102, 66)
        box = pygame.Surface(rect.size, pygame.SRCALPHA)
        box.fill((0, 0, 0, 190))
        screen.blit(box, rect.topleft)
        speaker = line.get("speaker", "")
        if speaker:
            self._text(screen, self.speaker_font, speaker, (225, 225, 225), rect.x + 13, rect.y + 7)
        lines = self._wrap(dialogue.visible_text, self.font, rect.width - 26)
        for index, text in enumerate(lines):
            self._text(screen, self.font, text, (245, 245, 245), rect.x + 13, rect.y + 29 + index * self.font.get_linesize())

    def plain(self, screen, dialogue, position="center", max_width=486):
        if dialogue.current_line is None:
            return
        lines = self._wrap(dialogue.visible_text, self.font, max_width)
        if not lines:
            return
        line_height = self.font.get_linesize()
        total_height = len(lines) * line_height
        if position == "center":
            y = (screen.get_height() - total_height) // 2
        elif position == "lower_center":
            y = int(screen.get_height() * 0.68)
        else:
            raise ValueError(f"Unknown plain dialogue position: {position}")
        for index, text in enumerate(lines):
            self._text(screen, self.font, text, (245, 245, 245), screen.get_width() // 2, y + index * line_height, center=True)

    def thought(self, screen, dialogue, max_width=358):
        if dialogue.current_line is None:
            return
        text = f"({dialogue.visible_text}" + (")" if dialogue.current_text_complete else "")
        lines = self._wrap(text, self.thought_font, max_width)
        y = int(screen.get_height() * 0.22)
        line_height = self.thought_font.get_linesize()
        for index, text in enumerate(lines):
            self._text(screen, self.thought_font, text, (220, 220, 230), screen.get_width() // 2 + 35, y + index * line_height, center=True)

    def help(self, screen, text):
        if not text:
            return
        padding_x, padding_y = 11, 7
        surface = self.help_font.render(text, True, (245, 245, 245))
        box = pygame.Surface((surface.get_width()+2*padding_x, surface.get_height()+2*padding_y), pygame.SRCALPHA)
        box.fill((0, 0, 0, 190))
        x = (screen.get_width() - box.get_width()) // 2
        y = 14
        screen.blit(box, (x, y))
        self._text(screen, self.help_font, text, (245, 245, 245), x + padding_x, y + padding_y)
