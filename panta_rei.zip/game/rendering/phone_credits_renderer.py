"""Credits typography and pixel-accurate projection onto the tilted phone."""
import pygame
from game.core.typography import Typography


class PhoneCreditsRenderer:
    # Four inset corners of the visible glass in the ORIGINAL 640x360 PNG.
    # Clockwise: top-left, top-right, bottom-right, bottom-left.
    # These points stay inside the bezel and below the speaker notch.
    SCREEN_QUAD = ((256, 55), (383, 43), (397, 287), (272, 298))
    # Credits are laid out on a straight virtual screen, then projected.
    GLASS = pygame.Rect(0, 0, 119, 231)

    def __init__(self, assets, display=None):
        self.assets = assets
        self.typography = Typography(assets)
        display = display or {}
        self.screen_quad = tuple(tuple(point) for point in display.get("screen_quad", self.SCREEN_QUAD))
        self.glass = pygame.Rect(display.get("virtual_glass", self.GLASS))
        # Legacy attribute aliases for existing scene and tests.
        self.SCREEN_QUAD = self.screen_quad
        self.GLASS = self.glass

    def font(self, size, italic=False):
        style = { (9, False): "credits_role", (12, False): "credits_name",
                  (10, True): "credits_other", (18, False): "credits_title" }.get((int(size), bool(italic)), "credits_subtitle")
        return self.typography.font(style)

    @staticmethod
    def outlined_text(font, label, color, outline=(8, 13, 25), radius=1):
        """Render crisp text with a dark one-pixel outline on a transparent surface."""
        glyph = font.render(label, True, color).convert_alpha()
        edge = font.render(label, True, outline).convert_alpha()
        result = pygame.Surface(
            (glyph.get_width() + radius * 2, glyph.get_height() + radius * 2),
            pygame.SRCALPHA,
        )
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                if dx or dy:
                    result.blit(edge, (radius + dx, radius + dy))
        result.blit(glyph, (radius, radius))
        return result

    def build_credits(self, entries):
        credit_surfaces = []
        total = 0
        for entry in entries:
            kind, label = entry['kind'], entry['text']
            if kind == 'role':
                font, color, gap = self.font(9), (158, 170, 184), 5
            elif kind == 'name':
                font, color, gap = self.font(12), (244, 241, 232), 26
            else:
                font, color, gap = self.font(10, True), (195, 201, 213), 26
            surf = self.outlined_text(font, label, color)
            # Guard against clipping long names on the narrow screen.
            if surf.get_width() > self.GLASS.width - 10:
                scale = (self.GLASS.width - 10) / surf.get_width()
                surf = pygame.transform.smoothscale(surf, (self.GLASS.width - 10, max(1, round(surf.get_height() * scale))))
            credit_surfaces.append((surf, gap))
            total += surf.get_height() + gap
        return credit_surfaces, total

    def draw_centered(self, surface, glyph, y):
        surface.blit(glyph, (self.GLASS.centerx - glyph.get_width() // 2, round(y)))

    def project_credits(self, screen, credits):
        """Map a straight credits surface onto the slanted phone glass.

        Row-wise scaling uses only Pygame, so packaged builds do not need
        OpenCV or NumPy. A quadrilateral alpha mask keeps every pixel inside
        the display, never over the bezel or hands.
        """
        tl, tr, br, bl = self.SCREEN_QUAD
        left = min(tl[0], bl[0])
        right = max(tr[0], br[0])
        top = min(tl[1], tr[1])
        bottom = max(bl[1], br[1])
        warped = pygame.Surface((right - left + 1, bottom - top + 1), pygame.SRCALPHA)
        # Project each horizontal credits row between the corresponding
        # points on the two sloping sides. The previous column-wise mapping
        # used a fixed x -> source-column relation, even though the phone's
        # horizontal boundaries shift with height. That made scrolling text
        # appear to drift sideways as it moved down the screen.
        source_height = credits.get_height()
        for src_y in range(source_height):
            v = (src_y + 0.5) / source_height
            left_x = tl[0] + v * (bl[0] - tl[0])
            right_x = tr[0] + v * (br[0] - tr[0])
            left_y = tl[1] + v * (bl[1] - tl[1])
            right_y = tr[1] + v * (br[1] - tr[1])
            width = max(1, round(right_x - left_x))
            row = credits.subsurface((0, src_y, credits.get_width(), 1))
            stretched = pygame.transform.scale(row, (width, 1))
            # Preserve the slant of the top and bottom screen edges.
            # Group nearby destination columns into short horizontal strips
            # rather than applying a fixed offset to the whole image.
            run_start = 0
            while run_start < width:
                u = (run_start + 0.5) / width
                dst_y = round(left_y + u * (right_y - left_y)) - top
                run_end = run_start + 1
                while run_end < width:
                    next_u = (run_end + 0.5) / width
                    if round(left_y + next_u * (right_y - left_y)) - top != dst_y:
                        break
                    run_end += 1
                warped.blit(stretched, (round(left_x) + run_start - left, dst_y),
                            area=pygame.Rect(run_start, 0, run_end - run_start, 1))
                run_start = run_end

        mask = pygame.Surface(warped.get_size(), pygame.SRCALPHA)
        points = [(x - left, y - top) for x, y in self.SCREEN_QUAD]
        pygame.draw.polygon(mask, (255, 255, 255, 255), points)
        warped.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        screen.blit(warped, (left, top))


    def render(self, screen, phase, phase_time, scroll_y, credit_surfaces):
        """Draw the complete credits presentation; narrative timing stays in Scene 12."""
        credits = pygame.Surface(self.glass.size, pygame.SRCALPHA)
        if phase in ("title", "final"):
            title = self.outlined_text(self.font(18), "PANTA REI", (246, 241, 228))
            subtitle = self.outlined_text(self.font(10, True), "A game by Jacopo Castellini", (180, 194, 209))
            if subtitle.get_width() > self.glass.width - 8:
                subtitle = pygame.transform.smoothscale(subtitle, (self.glass.width - 8, subtitle.get_height()))
            alpha = min(255, int(255 * min(1.0, phase_time / 0.7)))
            title.set_alpha(alpha)
            subtitle.set_alpha(alpha)
            self.draw_centered(credits, title, self.glass.centery - 21)
            self.draw_centered(credits, subtitle, self.glass.centery + 8)
        else:
            y = self.glass.top + scroll_y
            for surf, gap in credit_surfaces:
                self.draw_centered(credits, surf, y)
                y += surf.get_height() + gap
        self.project_credits(screen, credits)
