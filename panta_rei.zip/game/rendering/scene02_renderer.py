"""Compatibility import: use game.rendering.marco_pov_renderer in new code."""
from game.rendering.marco_pov_renderer import Scene02Renderer

__all__ = ["Scene02Renderer"]
