"""Compatibility import: use game.rendering.sky_panorama_renderer in new code."""
from game.rendering.sky_panorama_renderer import Scene11Renderer

__all__ = ["Scene11Renderer"]
