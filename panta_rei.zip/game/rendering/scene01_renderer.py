"""Compatibility import: use game.rendering.opening_sky_renderer in new code."""
from game.rendering.opening_sky_renderer import Scene01Renderer

__all__ = ["Scene01Renderer"]
