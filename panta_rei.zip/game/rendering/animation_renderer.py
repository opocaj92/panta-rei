"""Backward-compatible import for the reusable animation state system."""
from game.systems.animation import LoopingAnimation

__all__ = ["LoopingAnimation"]
