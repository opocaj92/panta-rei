"""Centralized font styles, consistent metrics and cached scaled glyph fonts."""
import json
from pathlib import Path
import pygame
from game.core.config import DATA_DIR, ASSETS_DIR


class Typography:
    """Own font identities and cache fonts by style, pixel size and italics."""

    def __init__(self, assets):
        self.assets = assets
        path = DATA_DIR / "presentation" / "typography.json"
        with path.open(encoding="utf-8") as file:
            self.styles = json.load(file)
        self._fonts = {}

    def font(self, style, scale=1.0):
        spec = self.styles[style]
        size = max(1, round(spec["size"] * float(scale)))
        italic = bool(spec.get("italic", False))
        key = (style, size, italic)
        if key not in self._fonts:
            path = ASSETS_DIR / spec.get("path", "")
            # None means Pygame's bundled default, not a machine-specific font.
            font = pygame.font.Font(str(path) if path.is_file() else None, size)
            font.set_italic(italic)
            self._fonts[key] = font
        return self._fonts[key]

    def scaled(self, style, scale):
        return self.font(style, scale)
